import boto3
import re


def rangeFiles(bucket:str, minPre:str, maxPre:str, fileRE:str):
	'''Return a list of the S3 objects in bucket with prefixes in the inclusive
	range between minPre and maxPre and file name that matches the fileRE
	regular expression
	
	Parameters:
		bucket (str:)	bucket name (w/o trailing separator)
		minPre (str:)	minimum prefix (w/o trailing separator)
		maxPre (str:)	maximum prefix (w/o trailing separator)
		fileRE (str:)	regular expression filter for file name
	Returns:
		(list:)			list of the object names in bucket (w/o bucket name)
	
	'''
	minlist = minPre.split('/')		# split each prefix into a list of accessors
	maxlist = maxPre.split('/')
	i = 0
	while i<len(minlist) and i<len(maxlist) and minlist[i]==maxlist[i]:
		i+= 1
	gcp = '/'.join(minlist[0:i])	# greatest common prefix of minPre and maxPre
	results = []
	client = boto3.client('s3')
	paginator = client.get_paginator('list_objects')
	operation_parameters = {'Bucket': bucket, 'Prefix': gcp}
	pageIterator = paginator.paginate(**operation_parameters)
	for page in pageIterator:		# for each each page of objects
		try:
			contents = page['Contents']
			for obj in contents:		# for each object in the page
				objName = obj['Key']
				fileName = objName.split('/')[-1]
				prefix = objName[0:-1-len(fileName)]	# w/o trailing "/"
				if minPre<=prefix and prefix <=maxPre and re.match(fileRE,fileName):
					results.append(objName)
		except:
			print(f"No results: page={page}")		
	return results
 